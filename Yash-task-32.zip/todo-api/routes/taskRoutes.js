
const express = require("express");
const { randomUUID } = require("crypto");

const router = express.Router();

let tasks = [];

// Add Task
router.post("/", (req, res) => {
    const { title, description, dueDate } = req.body;

    if (!title) {
        return res.status(400).json({
            message: "Task title is required"
        });
    }

    const newTask = {
        id: randomUUID(),
        title,
        description: description || "",
        dueDate: dueDate || null,
        status: "pending"
    };

    tasks.push(newTask);

    res.status(201).json({
        message: "Task added successfully",
        task: newTask
    });
});

// Get All Tasks and Filter Tasks
router.get("/", (req, res) => {
    const { status } = req.query;

    if (status) {
        const filteredTasks = tasks.filter(
            task => task.status === status
        );

        return res.status(200).json(filteredTasks);
    }

    res.status(200).json(tasks);
});

// Get Single Task
router.get("/:id", (req, res) => {
    const task = tasks.find(
        task => task.id === req.params.id
    );

    if (!task) {
        return res.status(404).json({
            message: "Task not found"
        });
    }

    res.status(200).json(task);
});

// Update Complete Task
router.put("/:id", (req, res) => {
    const task = tasks.find(
        task => task.id === req.params.id
    );

    if (!task) {
        return res.status(404).json({
            message: "Task not found"
        });
    }

    const { title, description, dueDate, status } = req.body;

    if (!title) {
        return res.status(400).json({
            message: "Task title is required"
        });
    }

    task.title = title;
    task.description = description || "";
    task.dueDate = dueDate || null;
    task.status = status || task.status;

    res.status(200).json({
        message: "Task updated successfully",
        task
    });
});

// Update Task Status
router.patch("/:id/status", (req, res) => {
    const task = tasks.find(
        task => task.id === req.params.id
    );

    if (!task) {
        return res.status(404).json({
            message: "Task not found"
        });
    }

    const { status } = req.body;

    if (!["pending", "completed"].includes(status)) {
        return res.status(400).json({
            message: "Invalid task status"
        });
    }

    task.status = status;

    res.status(200).json({
        message: "Task status updated successfully",
        task
    });
});

// Delete Task
router.delete("/:id", (req, res) => {
    const index = tasks.findIndex(
        task => task.id === req.params.id
    );

    if (index === -1) {
        return res.status(404).json({
            message: "Task not found"
        });
    }

    const deletedTask = tasks.splice(index, 1);

    res.status(200).json({
        message: "Task deleted successfully",
        task: deletedTask[0]
    });
});

module.exports = router;
