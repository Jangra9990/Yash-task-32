To-Do List REST API

 Project Description

This project is a To-Do List REST API developed using Node.js and Express.js. It allows users to create, view, update, filter, and delete tasks.

 Technologies Used
Node.js
 Express.js
 JavaScript

 Installation

 Clone or download the project.
 Open the project folder in VS Code.
 Run the following command:

bash
npm install


 Start the server:

bash
npm run dev


The server will run at:

http://localhost:5000

 API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| POST | /api/tasks | Create a new task |
| GET | /api/tasks | Get all tasks |
| GET | /api/tasks/:id | Get a single task |
| GET | /api/tasks?status=pending | Filter tasks by status |
| PUT | /api/tasks/:id | Update complete task |
| PATCH | /api/tasks/:id/status | Update task status |
| DELETE | /api/tasks/:id | Delete a task |

 Task Fields
 id: Unique task ID
 title: Task title (required)
 description: Task description
 dueDate: Task due date
 status: pending or completed

 Example Request

Create a Task:

json
{
  "title": "Learn Node.js",
  "description": "Practice REST APIs",
  "dueDate": "2026-11-20"
}


 Error Handling

- 400: Invalid request or missing task title
- 404: Task not found
- 201: Task created successfully
- 200: Request completed successfully

 Storage

Tasks are stored in an in-memory array. Data is reset when the server restarts.

 Author

Your Name